"""Remote command execution via Vercel Sandbox (Phase 9 add-on).

This is a *second* isolation layer, not a replacement for
`WorkspaceSandbox` (app/tools/sandbox.py). The distinction matters:

    * `WorkspaceSandbox` is a same-process path-string validator. It
      guarantees a tool can't construct a path that escapes the project
      workspace. It runs in the exact same OS process as everything else.
    * `VercelSandboxRuntime` (this module) moves the actual *execution* of
      `run_command` / `run_pytest` / `run_lint` / `run_typecheck` /
      `docker_build` / `docker_compose_up` / ... off the AHSEA host and
      into a disposable Firecracker microVM. A command that gets past
      every other guardrail -- a compromised worker, a poisoned
      dependency pulled in by `docker build`, an allowlisted-but-still-
      dangerous command -- is now contained by real hardware-level VM
      isolation, not just Python-level path checks.

Nothing about `WorkspaceSandbox` changes. `ctx.sandbox.resolve(...)` still
runs, still on the host, for every tool call, exactly as before -- it
still decides whether a *path* is legal. This module only changes where
the already-validated *argv* actually executes.

Wiring
------
Everything routes through one dispatch point, `_execute()` in
`app.tools.shell`, so no individual tool (`RunCommandTool`,
`DockerBuildTool`, etc.) needed to change. Turning this on is a
one-argument change at `ToolExecutor` construction time -- see
`app.tools.registry.make_executor(..., command_runtime=...)`.

Requires `pip install vercel` (this module was written and verified
against `vercel==0.10.0` by introspecting the installed package -- pin
it, since Sandbox is a young, fast-moving API surface and older/newer
releases have shipped different top-level functions). Auth is
environment-based, same as the rest of Vercel Sandbox: `VERCEL_OIDC_TOKEN`
when AHSEA itself runs on Vercel, or `VERCEL_TOKEN` + `VERCEL_TEAM_ID` +
`VERCEL_PROJECT_ID` for CI / self-hosted use. See
https://vercel.com/docs/sandbox/concepts/authentication.
"""

from __future__ import annotations

import asyncio
import io
import re
import tarfile
import time
from pathlib import Path

from vercel.sandbox import SandboxResources, get_or_create_sandbox
from vercel.sandbox import Sandbox as VercelSandboxHandle

from app.tools.exceptions import ToolTimeoutError
from app.tools.sandbox import WorkspaceSandbox

#: Where the synced project tree lives inside the microVM. `/vercel/sandbox`
#: is the writable root every Sandbox image ships with.
_REMOTE_WORKDIR = "/vercel/sandbox/workspace"
_SYNC_UP_TAR = "sync-up.tar"
_SYNC_DOWN_TAR = "sync-down.tar"

_MAX_OUTPUT_BYTES = 200_000  # matches app.tools.shell._MAX_OUTPUT_BYTES
_NAME_SAFE = re.compile(r"[^a-z0-9-]+")


def _sandbox_name(workspace_root: Path, *, prefix: str) -> str:
    """Derive a stable, Sandbox-name-legal identifier from a workspace path.

    Sandbox names must be unique per Vercel project and are how
    `get_or_create_sandbox` finds/resumes the *same* microVM across
    calls -- this is what lets AHSEA reuse one sandbox per project
    instead of booting a fresh one per tool call.
    """

    raw = f"{prefix}-{workspace_root.name}".lower()
    slug = _NAME_SAFE.sub("-", raw).strip("-") or "workspace"
    return slug[:63]  # generous headroom under typical name-length limits


class VercelSandboxRuntime:
    """Executes tool-system commands inside Vercel Sandbox microVMs.

    Create ONE instance per AHSEA process (or per project run) and pass it
    to every `make_executor(..., command_runtime=...)` call for that
    project. `get_or_create_sandbox()` is called before every command, so
    the *same* named microVM is resumed across calls for a given
    workspace rather than booting a fresh one each time -- cheap once the
    sandbox already exists, since resuming a stopped-but-persistent
    sandbox is far faster than a cold create.

    The workspace filesystem is synced in/out via tar around each
    command, so local file tools (`read_file`/`write_file`, which still
    go through the plain `WorkspaceSandbox` on the host) and remote
    command tools always see a consistent tree.
    """

    def __init__(
        self,
        *,
        vcpus: int = 2,
        execution_time_limit_seconds: int = 45 * 60,  # Hobby plan ceiling
        persistent: bool = False,
        project_id: str | None = None,
        name_prefix: str = "ahsea",
    ) -> None:
        self._vcpus = vcpus
        self._execution_time_limit = execution_time_limit_seconds
        self._persistent = persistent
        self._project_id = project_id
        self._name_prefix = name_prefix

        # sandbox name -> last-seen handle, kept only so `aclose()` can
        # tear every sandbox this runtime touched down without another
        # round trip to look each one up by name again.
        self._sandboxes: dict[str, VercelSandboxHandle] = {}
        # One lock per sandbox name so two tool calls for the *same*
        # project never race on sync-up/sync-down against the same
        # microVM; different projects still run fully in parallel.
        self._locks: dict[str, asyncio.Lock] = {}

    async def _sync_up(self, sandbox: VercelSandboxHandle, local_root: Path) -> None:
        """Push the host's copy of the workspace into the microVM.

        Whole-tree tar round-trip, not an incremental diff -- simple and
        correct, and fine for project-sized workspaces. If this becomes a
        bottleneck on large repos, switch to per-changed-file
        `sandbox.fs.write_bytes()` calls (track mtimes) instead of a full
        tar every command.
        """

        buf = io.BytesIO()
        with tarfile.open(fileobj=buf, mode="w") as tar:
            tar.add(local_root, arcname=".")

        await sandbox.fs.mkdir(_REMOTE_WORKDIR, recursive=True)
        await sandbox.fs.write_bytes(_SYNC_UP_TAR, buf.getvalue(), cwd=_REMOTE_WORKDIR)
        result = await sandbox.run_process(
            "tar", ["-xf", _SYNC_UP_TAR], cwd=_REMOTE_WORKDIR, capture_output=True
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"Vercel Sandbox workspace sync-up failed: {result.stderr}"
            )

    async def _sync_down(self, sandbox: VercelSandboxHandle, local_root: Path) -> None:
        """Pull the microVM's tree back onto disk.

        Needed because remote commands change files a *local* tool reads
        next: `git commit` moves HEAD, `docker build` can drop build
        artifacts, `pytest --cov` writes `.coverage`, etc. Without this,
        the host's `WorkspaceSandbox` view would silently drift from what
        actually happened inside the microVM.
        """

        result = await sandbox.run_process(
            "tar",
            ["-cf", _SYNC_DOWN_TAR, f"--exclude={_SYNC_UP_TAR}", "."],
            cwd=_REMOTE_WORKDIR,
            capture_output=True,
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"Vercel Sandbox workspace sync-down failed: {result.stderr}"
            )
        data = await sandbox.fs.read_bytes(_SYNC_DOWN_TAR, cwd=_REMOTE_WORKDIR)
        with tarfile.open(fileobj=io.BytesIO(data), mode="r") as tar:
            tar.extractall(local_root, filter="data")

    async def run(
        self,
        argv: list[str],
        *,
        workspace: WorkspaceSandbox,
        timeout: float,
    ) -> tuple[int, str, str]:
        """Drop-in replacement for `app.tools.shell._run_subprocess`.

        Same return shape -- `(returncode, stdout, stderr)` -- so callers
        (`RunCommandTool`, `DockerBuildTool`, etc., via `_execute()` in
        `app.tools.shell`) don't need to know or care whether the command
        actually ran on the host or inside a microVM.

        `argv` has already passed `validate_command`/`validate_docker_command`
        by the time it reaches here -- this function trusts its caller the
        same way `_run_subprocess` does.
        """

        name = _sandbox_name(workspace.root, prefix=self._name_prefix)
        lock = self._locks.setdefault(name, asyncio.Lock())
        async with lock:
            sandbox, _created = await get_or_create_sandbox(
                name=name,
                project_id=self._project_id,
                persistent=self._persistent,
                resources=SandboxResources(vcpus=self._vcpus),
                execution_time_limit=self._execution_time_limit,
            )
            self._sandboxes[name] = sandbox

            await self._sync_up(sandbox, workspace.root)

            started = time.monotonic()
            completed = await sandbox.run_process(
                argv[0],
                argv[1:],
                cwd=_REMOTE_WORKDIR,
                kill_after=timeout,
                capture_output=True,
            )
            elapsed = time.monotonic() - started

            await self._sync_down(sandbox, workspace.root)

            # `kill_after` is enforced server-side (SIGKILL once `timeout`
            # elapses); it doesn't raise, it just returns a killed
            # process's result. Distinguish "killed for exceeding the
            # budget" from "ran fine and legitimately exited non-zero" by
            # elapsed wall-clock time, so callers see the same
            # `ToolTimeoutError` they'd get from a locally-killed
            # subprocess.
            if completed.returncode != 0 and elapsed >= timeout - 0.5:
                raise ToolTimeoutError(
                    f"Command {' '.join(argv)!r} exceeded {timeout}s on Vercel "
                    "Sandbox and was killed."
                )

            stdout = (completed.stdout or "")[:_MAX_OUTPUT_BYTES]
            stderr = (completed.stderr or "")[:_MAX_OUTPUT_BYTES]
            return completed.returncode, stdout, stderr

    async def aclose(self) -> None:
        """Tear down every microVM this runtime touched.

        Call once when a project run finishes -- success, failure, or
        cancellation -- e.g. from the same `finally` block that already
        tears down the project's `ToolExecutor`/`AuditLog`. With
        `persistent=False` (the default) this fully removes the sandbox;
        with `persistent=True` it stops the session but Vercel keeps a
        filesystem snapshot so a later run with the same workspace can
        resume instantly instead of re-syncing from scratch. Idle
        Hobby-plan sandboxes still burn your 5 free Active-CPU hours/month
        while running, so don't rely solely on the execution-time-limit
        ceiling to clean up after you.
        """

        for sandbox in self._sandboxes.values():
            if self._persistent:
                await sandbox.stop()
            else:
                await sandbox.destroy()
        self._sandboxes.clear()
